# swordSniffer [![Build Status](https://travis-ci.org/onestraw/sniffer.svg?branch=master)](https://travis-ci.org/onestraw/sniffer)

A graphical network packet sniffer.

Just a toy


## Deps

- Gtk+3.0
- Glade3.0
- libpcap

## Build

    git clone https://github.com/onestraw/sniffer
    cd sniffer
    make
    sudo ./sniffer

## Screenshot
![sniffer](run-screenshot.png)
